package mx.ipn.escom.sprint.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class Holaa {

    @GetMapping("/hola")
    public String decirHola() {
        return "¡Hola Spring! MSL";
    }
}
