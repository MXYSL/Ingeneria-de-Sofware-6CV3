<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "spring_auth";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
