package spring.service;

public interface UserDetails {

}
