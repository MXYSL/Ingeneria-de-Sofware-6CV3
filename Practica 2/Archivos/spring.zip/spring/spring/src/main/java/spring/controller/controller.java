package spring.controller;

public @interface controller {

}
