package spring.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import spring.entity.Usuario;
import spring.repository.UsuarioRepository;
import spring.service.UsuarioService;

@SuppressWarnings("unused")
@Controller
public class UsuarioController {
    
    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Mostrar todos los usuarios
    @GetMapping("/usuarios")
    public String listarUsuarios(Model model) {
        List<Usuario> usuarios = usuarioService.obtenerTodosLosUsuarios();
        model.addAttribute("usuarios", usuarios);
        return "usuarios";  
    }

    // Crear nuevo usuario
    @GetMapping("/usuarios/nuevo")
    public String mostrarFormularioCreacion(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "crearUsuario";  
    }

    @PostMapping("/usuarios")
    public String crearUsuario(@ModelAttribute Usuario usuario) {
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        usuarioService.guardarUsuario(usuario);
        return "redirect:/admin/usuarios";  
    }

    // Ver un usuario por ID
    @GetMapping("/usuarios/{id}")
    public String verUsuario(@PathVariable("id") Long id, Model model) {
        Optional<Usuario> usuario = usuarioService.obtenerUsuarioPorId(id);
        if (usuario.isPresent()) {
            model.addAttribute("usuario", usuario.get());
            return "verUsuario";  
        }
        return "redirect:/admin/usuarios";
    }

    // Actualizar un usuario
    @GetMapping("/usuarios/editar/{id}")
    public String mostrarFormularioEdicion(@PathVariable("id") Long id, Model model) {
        Optional<Usuario> usuario = usuarioService.obtenerUsuarioPorId(id);
        if (usuario.isPresent()) {
            model.addAttribute("usuario", usuario.get());
            return "editarUsuario";  
        }
        return "redirect:/admin/usuarios";
    }

    @PostMapping("/usuarios/editar/{id}")
    public String actualizarUsuario(@PathVariable("id") Long id, @ModelAttribute Usuario usuario) {
        Optional<Usuario> usuarioExistente = usuarioService.obtenerUsuarioPorId(id);
        if (usuarioExistente.isPresent()) {
            Usuario usuarioGuardado = usuarioExistente.get();
            usuarioGuardado.setNombre(usuario.getNombre());
            usuarioGuardado.setEmail(usuario.getEmail());
            
            if (!usuario.getPassword().isEmpty()) {
                usuarioGuardado.setPassword(passwordEncoder.encode(usuario.getPassword()));  
            }
            usuarioService.guardarUsuario(usuarioGuardado);
        }
        return "redirect:/admin/usuarios";  
    }

    // Eliminar usuario por ID
    @GetMapping("/usuarios/eliminar/{id}")
    public String eliminarUsuario(@PathVariable("id") Long id, Model model) {
        usuarioService.eliminarUsuario(id);
        model.addAttribute("mensaje", "Usuario eliminado exitosamente");
        return "redirect:/usuarios";  
    }

    // Eliminar todos los usuarios (opcional)
    @GetMapping("/usuarios/eliminar")
    public String eliminarTodosLosUsuarios() {
        usuarioService.eliminarTodos();
        return "redirect:/usuarios";
    }

    @PostMapping("/user/register")
    public String registrarUsuario(@ModelAttribute Usuario usuario) {
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        usuarioService.guardarUsuario(usuario);
        return "redirect:/login";
    }
}
