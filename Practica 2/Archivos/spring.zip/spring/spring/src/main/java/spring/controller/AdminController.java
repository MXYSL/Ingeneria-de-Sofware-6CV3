package spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import spring.entity.Rol;
import spring.entity.Usuario;
import spring.repository.UsuarioRepository;
import spring.repository.RolRepository;

@Controller
public class AdminController {
    private final String API_URL = "https://localhost:8080/api";  // URL de la API

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private UsuarioRepository userRepository;

    @Autowired
    private RolRepository roleRepository;

    @GetMapping("/admin")
    public String adminPage(Authentication authentication, Model model) {
        System.out.println("Usuario autenticado: " + authentication.getName());
        System.out.println("Roles del usuario: " + authentication.getAuthorities());

        if (authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_ADMIN"))) {
            System.out.println("Acceso concedido: Usuario es admin");

            ResponseEntity<Usuario[]> response = restTemplate.getForEntity(API_URL + "/users", Usuario[].class);
            model.addAttribute("usuarios", response.getBody());
            return "admin";
        } else {
            System.out.println("Acceso denegado: Usuario no es admin");
            return "accessDenied";
        }
    }

    @PostMapping("/admin/users")
    public String addUser(@ModelAttribute Usuario usuario) {
        ResponseEntity<String> response = restTemplate.postForEntity(API_URL + "/register", usuario, String.class);
        if (response.getStatusCode().is2xxSuccessful()) {
            return "redirect:/admin";
        }
        return "error";  
    }

    @PostMapping("/admin/users/{id}/delete")
    public String deleteUser(@PathVariable Long id) {
        try {
            restTemplate.delete(API_URL + "/users/" + id);
        } catch (Exception e) {
            System.out.println("Error al eliminar usuario: " + e.getMessage());
            return "error";
        }
        return "redirect:/admin";
    }

    @PostMapping("/admin/users/{id}/toggle-admin")
    public String toggleAdmin(@PathVariable Long id) {
        Usuario usuario = userRepository.findById(id).orElse(null);
        
        if (usuario != null) {
            if (usuario.getRoles().stream().anyMatch(rol -> rol.getNombre().equals("ROLE_ADMIN"))) {
                usuario.getRoles().removeIf(rol -> rol.getNombre().equals("ROLE_ADMIN"));
            } else {
                Rol adminRole = roleRepository.findByNombre("ROLE_ADMIN")
                    .orElseThrow(() -> new RuntimeException("Rol no encontrado"));
                usuario.getRoles().add(adminRole);
            }
            userRepository.save(usuario);
        }
        return "redirect:/admin";
    }
}
